const jobs = {
  "job-1": {
    type: "Permanent",
    title: "Design Disruptor",
    desc: "A Design Director orchestrates visual narratives, transforming concepts into compelling designs. They harness a blend of creative vision and strategic insight to guide projects from inception to fruition. Whether leveraging digital tools or traditional methods, they craft visually stunning creations that resonate with audiences. A Design Director leaves an indelible artistic imprint across diverse projects, shaping brand identities and enhancing storytelling through design."
  },
  "job-2": {
    type: "Contract",
    title: "Innovation Inventor",
    desc: "Invention involves the discovery of something new, while innovation entails the utilization of a novel idea or method. Innovation is the act of introducing fresh concepts or approaches to the market and transforming existing inventions into practical products or processes that have real-world utility."
  },
  "job-3": {
    type: "Freelance",
    title:"Director Of Fun",
    desc: "Instead of being employed in a permanent position by a company, freelancers work on a per project or contract basis, often for numerous different clients or companies. They are self-employed, meaning they are considered to work for themselves.."
  },
  "job-4": {
    type: "Permanent",
    title: "Web master",
    desc: "In a smaller company, a webmaster typically takes care of all the technology related to the website. In a larger company, a webmaster tends to be someone with knowledge and experience with Hypertext Markup Language (HTML) and Cascading Style Sheets (CSS) for styling, or a more technical person with some programming skills. The webmaster runs the server -- for example, by managing the creation and authorization associated with file systems -- and writes programs or Perl scripts required by the website."
  }
}

const filtersList = {
  0 : { name: "all" }, 
  1 : { name: "permanent" },
  2 : { name: "contract" },
  3 : { name: "freelance" }
}

// Header
// ================================
function Header() {
  return (
    <div className="c-header">
      <div className="o-wrap">
        <h1>JOBFORU</h1>
      </div>
    </div>
  )
}

// Filters
// ================================
class Filters extends React.Component {
  constructor() {
    super();
  }
  
  getFilter(e) {
    e.preventDefault();
    const id = e.target.getAttribute('id');
    const name = e.target.textContent.toLowerCase();
    const filter = {
      id,
      name
    }
    this.props.updateList(filter);
  }
  
  render() {
    return (
      <div className="c-filters">
        <div className="o-wrap">
          <h2>FILTERS</h2>
          <ul>
            {
              Object
                .keys(this.props.filters)
                .map(key => 
                  <li className={'c-filter-link'}>
                     <a href="#" onClick={this.getFilter.bind(this)} id={key}>{this.props.filters[key].name}</a>
                  </li>
                )
            }
          </ul>
        </div>
      </div>
    )
  }
}

// Job List
// ================================
class JobList extends React.Component {
  render() {
    return (
      <div className="c-job-list">
        <div className="o-wrap">
          <h2>Job List</h2>
          <ul>
            {
              Object
                .keys(this.props.jobs)
                .map(key => <Job key={key} details={this.props.jobs[key]}/>)
            }
          </ul>
        </div>
      </div>
    )
  }
}

class Job extends React.Component {
  render() {
    return(
      <li className={'c-job-item c-job-item--' + this.props.details.type.toLowerCase()}>
        <span className="c-job-item__type">{this.props.details.type}</span>
        <h3 className="c-job-item__title">{this.props.details.title}</h3>
        <p className="c-job-item__desc">{this.props.details.desc}</p>
      </li>
    )
  }
}

// APP
// ================================
class App extends React.Component {
  constructor() {
    super();
    this.state = {
      jobs,
      jobsFiltered: {},
      filtersList,
      currentFilter: {
        id: 0,
        name: "all"
      }
    }
    
    this.updateList = this.updateList.bind(this);
  }
  
  componentWillMount() {
    this.setState({jobsFiltered: jobs})
  }
 
  updateList(filter) {
    this.setState({
      currentFilter: filter
    }, filterList);
    
    function filterList(filter) {
      console.log(this.state.currentFilter.name);
      var updatedList = this.state.jobs;

      updatedList = Object.keys(updatedList).map((key) => updatedList[key])
        .filter((key) => {
        return key.type.toLowerCase() === this.state.currentFilter.name;
      });
      
      if(this.state.currentFilter.name === "all") {
        this.setState({
          jobsFiltered: jobs
        }); 
      } else {
        this.setState({
          jobsFiltered: updatedList
        });
      }
    }
  }
  
  render() {
    return(
      <div className="o-app">
        <Header />
        <Filters updateList={this.updateList} filters={this.state.filtersList} />
        <JobList jobs={this.state.jobsFiltered} />
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.querySelector('#root')
);